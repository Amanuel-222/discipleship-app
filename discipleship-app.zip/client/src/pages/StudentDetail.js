import React, { useEffect, useState, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { api } from "../utils/api";
import { useToast } from "../utils/toast";

function formatDate(iso) {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export default function StudentDetail() {
  const { id } = useParams();
  const [student, setStudent] = useState(null);
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const toast = useToast();

  const loadNotes = useCallback(
    () => api.getNotes(id).then(setNotes),
    [id]
  );

  useEffect(() => {
    api.getStudent(id).then(setStudent).catch(() => setStudent(null));
    loadNotes();
  }, [id, loadNotes]);

  const addNote = async () => {
    if (!newNote.trim()) return;
    setSubmitting(true);
    try {
      await api.addNote(id, newNote.trim());
      setNewNote("");
      await loadNotes();
      toast("Note added ✓");
    } catch (e) {
      toast("Error: " + e.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleKey = (e) => {
    // Ctrl/Cmd + Enter to submit
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") addNote();
  };

  const deleteNote = async (nid) => {
    if (!window.confirm("Delete this note?")) return;
    await api.deleteNote(nid);
    await loadNotes();
    toast("Note deleted");
  };

  if (!student)
    return <div className="loading">Loading student…</div>;

  return (
    <div>
      {/* Header */}
      <div className="page-header">
        <div>
          <Link
            to="/students"
            style={{ fontSize: "0.85rem", color: "var(--text-muted)" }}
          >
            ← All Students
          </Link>
          <h2 style={{ marginTop: 6 }}>{student.name}</h2>
          {student.email && (
            <p>
              <a href={`mailto:${student.email}`}>{student.email}</a>
            </p>
          )}
        </div>
        <Link
          to={`/students`}
          className="btn btn-secondary btn-sm"
          style={{ alignSelf: "flex-start" }}
        >
          Back
        </Link>
      </div>

      {/* General notes banner */}
      {student.notes && (
        <div
          className="card"
          style={{
            marginBottom: 20,
            background: "var(--accent-light)",
            border: "1px solid #b2d8c4",
          }}
        >
          <div
            style={{
              fontSize: "0.72rem",
              fontWeight: 700,
              textTransform: "uppercase",
              letterSpacing: "0.06em",
              color: "var(--accent)",
              marginBottom: 6,
            }}
          >
            General Notes
          </div>
          <p style={{ fontSize: "0.9rem", color: "var(--accent-hover)" }}>
            {student.notes}
          </p>
        </div>
      )}

      {/* Progress notes */}
      <div className="card">
        <h3
          style={{
            fontFamily: "var(--font-display)",
            fontSize: "1.05rem",
            marginBottom: 18,
          }}
        >
          Progress Notes
        </h3>

        {/* Add note area */}
        <div style={{ marginBottom: 24 }}>
          <textarea
            className="form-control"
            style={{ minHeight: 72, marginBottom: 8 }}
            placeholder='Add a progress note… e.g. "More engaged this week, asked about prayer."'
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            onKeyDown={handleKey}
          />
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <span style={{ fontSize: "0.75rem", color: "var(--text-light)" }}>
              ⌘+Enter to save
            </span>
            <button
              className="btn btn-primary btn-sm"
              onClick={addNote}
              disabled={submitting || !newNote.trim()}
            >
              {submitting ? "Saving…" : "Add Note"}
            </button>
          </div>
        </div>

        {/* Notes list */}
        {notes.length === 0 ? (
          <div
            style={{
              textAlign: "center",
              padding: "32px 0",
              color: "var(--text-muted)",
              fontSize: "0.9rem",
            }}
          >
            No progress notes yet.
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {notes.map((n) => (
              <div
                key={n._id}
                style={{
                  display: "flex",
                  gap: 12,
                  alignItems: "flex-start",
                  padding: "12px 14px",
                  background: "var(--bg)",
                  borderRadius: 8,
                  border: "1px solid var(--border)",
                }}
              >
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: "0.9rem", lineHeight: 1.5 }}>{n.text}</p>
                  <time
                    style={{
                      display: "block",
                      marginTop: 6,
                      fontSize: "0.72rem",
                      color: "var(--text-light)",
                    }}
                  >
                    {formatDate(n.createdAt)}
                  </time>
                </div>
                <button
                  className="btn btn-ghost btn-sm"
                  onClick={() => deleteNote(n._id)}
                  style={{ color: "var(--danger)", flexShrink: 0 }}
                  title="Delete note"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
