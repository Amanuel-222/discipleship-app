import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../utils/api";
import { useToast } from "../utils/toast";

function StudentModal({ student, onClose, onSave }) {
  const [form, setForm] = useState(
    student || { name: "", email: "", notes: "" }
  );
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  return (
    <div
      className="modal-overlay"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="modal">
        <h3>{student ? "Edit Student" : "Add Student"}</h3>

        <div className="form-group">
          <label>Name *</label>
          <input
            className="form-control"
            value={form.name}
            onChange={set("name")}
            placeholder="Full name"
            autoFocus
          />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input
            className="form-control"
            value={form.email}
            onChange={set("email")}
            placeholder="email@example.com"
          />
        </div>
        <div className="form-group">
          <label>Notes</label>
          <textarea
            className="form-control"
            value={form.notes}
            onChange={set("notes")}
            placeholder="General notes about this student…"
          />
        </div>

        <div className="modal-actions">
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button
            className="btn btn-primary"
            onClick={() => form.name.trim() && onSave(form)}
            disabled={!form.name.trim()}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Students() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  // modal: null | "add" | <student object>
  const [modal, setModal] = useState(null);
  const toast = useToast();

  const load = () =>
    api.getStudents().then(setStudents).finally(() => setLoading(false));

  useEffect(() => {
    load();
  }, []);

  const handleSave = async (form) => {
    try {
      if (modal === "add") {
        await api.createStudent(form);
        toast("Student added ✓");
      } else {
        await api.updateStudent(modal._id, form);
        toast("Student updated ✓");
      }
      setModal(null);
      load();
    } catch (e) {
      toast("Error: " + e.message);
    }
  };

  const handleDelete = async (s) => {
    if (!window.confirm(`Delete ${s.name}? This cannot be undone.`)) return;
    try {
      await api.deleteStudent(s._id);
      toast(`${s.name} removed`);
      load();
    } catch (e) {
      toast("Error: " + e.message);
    }
  };

  if (loading) return <div className="loading">Loading students…</div>;

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Students</h2>
          <p>{students.length} enrolled</p>
        </div>
        <button className="btn btn-primary" onClick={() => setModal("add")}>
          + Add Student
        </button>
      </div>

      {modal && (
        <StudentModal
          student={modal === "add" ? null : modal}
          onClose={() => setModal(null)}
          onSave={handleSave}
        />
      )}

      {students.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">👤</div>
          <p>No students yet. Add your first one!</p>
        </div>
      ) : (
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Notes</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {students.map((s) => (
                  <tr key={s._id}>
                    <td>
                      <Link
                        to={`/students/${s._id}`}
                        style={{
                          fontWeight: 600,
                          color: "var(--accent)",
                        }}
                      >
                        {s.name}
                      </Link>
                    </td>
                    <td style={{ color: "var(--text-muted)" }}>
                      {s.email || "—"}
                    </td>
                    <td
                      style={{
                        color: "var(--text-muted)",
                        maxWidth: 240,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {s.notes || "—"}
                    </td>
                    <td>
                      <div style={{ display: "flex", gap: 6 }}>
                        <Link
                          to={`/students/${s._id}`}
                          className="btn btn-ghost btn-sm"
                        >
                          View
                        </Link>
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={() => setModal(s)}
                        >
                          Edit
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleDelete(s)}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
