import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../utils/api";

function ProgressBar({ pct }) {
  const color = pct === null ? "" : pct >= 75 ? "" : pct >= 50 ? "warn" : "danger";
  return (
    <div className="progress-bar">
      <div
        className={`progress-bar-fill ${color}`}
        style={{ width: `${pct ?? 0}%` }}
      />
    </div>
  );
}

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getDashboardStats().then(setData).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading">⏳ Loading dashboard…</div>;
  if (!data) return null;

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Dashboard</h2>
          <p>Overview of your discipleship class</p>
        </div>
      </div>

      {/* Stat cards */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 16,
          marginBottom: 28,
        }}
      >
        {[
          { label: "Total Students", value: data.totalStudents, icon: "👤" },
          { label: "Sessions Held", value: data.totalSessions, icon: "📅" },
          { label: "Assignments", value: data.totalAssignments, icon: "📝" },
        ].map((s) => (
          <div key={s.label} className="card" style={{ textAlign: "center" }}>
            <div style={{ fontSize: "1.8rem", marginBottom: 8 }}>{s.icon}</div>
            <div
              style={{
                fontSize: "2rem",
                fontWeight: 700,
                color: "var(--accent)",
              }}
            >
              {s.value}
            </div>
            <div
              style={{
                fontSize: "0.8rem",
                color: "var(--text-muted)",
                marginTop: 2,
              }}
            >
              {s.label}
            </div>
          </div>
        ))}
      </div>

      {/* Student progress table */}
      <div className="card">
        <h3
          style={{
            fontFamily: "var(--font-display)",
            marginBottom: 16,
            fontSize: "1.05rem",
          }}
        >
          Student Progress
        </h3>

        {data.students.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">👤</div>
            <p>No students yet. Add some from the Students page.</p>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Attendance</th>
                  <th>Assignments</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {data.students.map((s) => (
                  <tr key={s._id}>
                    <td style={{ fontWeight: 500 }}>{s.name}</td>

                    <td>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                        }}
                      >
                        <ProgressBar pct={s.attendancePct} />
                        <span
                          style={{
                            fontSize: "0.8rem",
                            color: "var(--text-muted)",
                            minWidth: 36,
                          }}
                        >
                          {s.attendancePct !== null
                            ? `${s.attendancePct}%`
                            : "—"}
                        </span>
                      </div>
                      <div
                        style={{
                          fontSize: "0.72rem",
                          color: "var(--text-light)",
                          marginTop: 3,
                        }}
                      >
                        {s.attendanceLabel} sessions
                      </div>
                    </td>

                    <td>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                        }}
                      >
                        <ProgressBar pct={s.assignmentPct} />
                        <span
                          style={{
                            fontSize: "0.8rem",
                            color: "var(--text-muted)",
                            minWidth: 36,
                          }}
                        >
                          {s.assignmentPct !== null
                            ? `${s.assignmentPct}%`
                            : "—"}
                        </span>
                      </div>
                      <div
                        style={{
                          fontSize: "0.72rem",
                          color: "var(--text-light)",
                          marginTop: 3,
                        }}
                      >
                        {s.assignmentLabel} submitted
                      </div>
                    </td>

                    <td>
                      <Link
                        to={`/students/${s._id}`}
                        className="btn btn-ghost btn-sm"
                      >
                        View →
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
