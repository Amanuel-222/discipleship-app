import React, { useState } from "react";
import { BrowserRouter, Routes, Route, NavLink, useLocation } from "react-router-dom";
import { ToastProvider } from "./utils/toast";

import Dashboard from "./pages/Dashboard";
import Students from "./pages/Students";
import StudentDetail from "./pages/StudentDetail";
import Attendance from "./pages/Attendance";
import Assignments from "./pages/Assignments";

const NAV = [
  { to: "/", label: "Dashboard", icon: "📊" },
  { to: "/students", label: "Students", icon: "👤" },
  { to: "/attendance", label: "Attendance", icon: "📅" },
  { to: "/assignments", label: "Assignments", icon: "📝" },
];

function Sidebar({ open, onClose }) {
  const location = useLocation();
  return (
    <>
      {open && <div className="sidebar-overlay" onClick={onClose} />}
      <nav className={`sidebar ${open ? "open" : ""}`}>
        <div className="sidebar-logo">
          <h1>Discipleship<br />Class</h1>
          <span>Class Manager</span>
        </div>
        <div className="sidebar-nav">
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.to === "/"}
              className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}
              onClick={onClose}
            >
              <span className="nav-icon">{n.icon}</span>
              {n.label}
            </NavLink>
          ))}
        </div>
      </nav>
    </>
  );
}

function Shell() {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <div className="app-shell">
      <header className="mobile-header">
        <h1>Discipleship Class</h1>
        <button className="hamburger" onClick={() => setMenuOpen((v) => !v)}>☰</button>
      </header>
      <Sidebar open={menuOpen} onClose={() => setMenuOpen(false)} />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/students" element={<Students />} />
          <Route path="/students/:id" element={<StudentDetail />} />
          <Route path="/attendance" element={<Attendance />} />
          <Route path="/assignments" element={<Assignments />} />
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <Shell />
      </ToastProvider>
    </BrowserRouter>
  );
}
