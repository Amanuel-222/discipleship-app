const router = require("express").Router();
const Student = require("../models/Student");
const Attendance = require("../models/Attendance");
const Assignment = require("../models/Assignment");
const Note = require("../models/Note");

// GET all students
router.get("/", async (req, res) => {
  try {
    const students = await Student.find().sort({ name: 1 });
    res.json(students);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single student
router.get("/:id", async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) return res.status(404).json({ error: "Student not found" });
    res.json(student);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create student — also adds them to all existing sessions/assignments
router.post("/", async (req, res) => {
  try {
    const { name, email, notes } = req.body;
    const student = await Student.create({ name, email, notes });

    // Add student to all existing attendance sessions
    await Attendance.updateMany(
      {},
      { $push: { records: { student: student._id, present: false } } }
    );

    // Add student to all existing assignments
    await Assignment.updateMany(
      {},
      { $push: { submissions: { student: student._id, submitted: false } } }
    );

    res.status(201).json(student);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT update student
router.put("/:id", async (req, res) => {
  try {
    const { name, email, notes } = req.body;
    const student = await Student.findByIdAndUpdate(
      req.params.id,
      { name, email, notes },
      { new: true, runValidators: true }
    );
    if (!student) return res.status(404).json({ error: "Student not found" });
    res.json(student);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE student — also removes from sessions/assignments/notes
router.delete("/:id", async (req, res) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);
    if (!student) return res.status(404).json({ error: "Student not found" });

    // Remove from attendance records
    await Attendance.updateMany(
      {},
      { $pull: { records: { student: req.params.id } } }
    );
    // Remove from assignment submissions
    await Assignment.updateMany(
      {},
      { $pull: { submissions: { student: req.params.id } } }
    );
    // Delete all notes for this student
    await Note.deleteMany({ student: req.params.id });

    res.json({ message: "Student deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET dashboard stats
router.get("/dashboard/stats", async (req, res) => {
  try {
    const students = await Student.find();
    const sessions = await Attendance.find();
    const assignments = await Assignment.find();

    const stats = students.map((s) => {
      const sid = s._id.toString();

      // Attendance %
      let presentCount = 0;
      let totalSessions = sessions.length;
      sessions.forEach((session) => {
        const rec = session.records.find((r) => r.student.toString() === sid);
        if (rec && rec.present) presentCount++;
      });
      const attendancePct = totalSessions > 0 ? Math.round((presentCount / totalSessions) * 100) : null;

      // Assignment completion %
      let submittedCount = 0;
      let totalAssignments = assignments.length;
      assignments.forEach((a) => {
        const sub = a.submissions.find((r) => r.student.toString() === sid);
        if (sub && sub.submitted) submittedCount++;
      });
      const assignmentPct = totalAssignments > 0 ? Math.round((submittedCount / totalAssignments) * 100) : null;

      return {
        _id: s._id,
        name: s.name,
        email: s.email,
        attendancePct,
        attendanceLabel: `${presentCount}/${totalSessions}`,
        assignmentPct,
        assignmentLabel: `${submittedCount}/${totalAssignments}`,
      };
    });

    res.json({
      totalStudents: students.length,
      totalSessions,
      totalAssignments: assignments.length,
      students: stats,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
